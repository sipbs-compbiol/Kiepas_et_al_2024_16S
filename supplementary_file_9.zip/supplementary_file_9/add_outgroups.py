"""This scripts was used to add outgroups to our sequences clustered at 100%, 
and remove forbiden chacaters from FASTA headers.
"""

from Bio import SeqIO
from pathlib import Path

sequences = list(SeqIO.parse(Path("~/Desktop/Kiepas_et_al_2023_16S/supplementary_file_5/clusters/centroid_seq/length_c100.fasta").expanduser(), "fasta"))
outgroups = list(SeqIO.parse(Path("~/Desktop/Kiepas_et_al_2023_16S/supplementary_file_9/data/outgroups.fasta").expanduser(), "fasta"))



def change_FASTA_headers(data):
    """Remove cluster size infomration
    from FASTA headers
    """

    for _ in data:
        _.description = _.description.split(';')[0]
        _.name = _.description
        _.id = _.description

    return data


sequences = change_FASTA_headers(sequences)
outgroup = change_FASTA_headers(outgroups)

new_sequences = sequences+outgroups


SeqIO.write(new_sequences, Path("~/Desktop/Kiepas_et_al_2023_16S/supplementary_file_9/data/zOTUs_with_outgroups.fasta").expanduser(), "fasta")