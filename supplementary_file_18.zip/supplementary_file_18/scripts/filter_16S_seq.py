"""This script was used to filter the extracted 16S rRNA sequences by retaining only
sequences from genomes that do not dontain a single 16S rRNA sequence with ambiguity symbol, 
or partial sequences (less than 1200bp long). 
"""

#Set Up
from Bio import SeqIO
import re
import pandas as pd
import hashlib
from collections import defaultdict

#Load data
records = list(SeqIO.parse("../output/16S_seq_from_strep_genomes.fasta", "fasta"))

#Get genomes which have a partial 16S rrNA sequence, or have ambiguity symbols within 16S records
genomes_with_partial_records = [_.description for _ in records if len(_.seq) <1200]
genomes_with_ambiguity = [_.description for _ in records if re.search(r"[^ATGC]", str(_.seq)) != None]

dicard = genomes_with_partial_records + genomes_with_ambiguity

#Extract sequences which are complete (longer than 1200bp), and do not have a single ambiuity symbol
clean_records = ([_ for _ in records if len(_.seq) >= 1200 and re.search(r"[^ATGC]", str(_.seq)) == None and _.description not in dicard])

SeqIO.write(clean_records, "../output/filtered_16S_seq_from_strep_genomes.fasta", "fasta")

retain_genomes = list(set([_.description for _ in clean_records]))
with open("../data/retained_genomes.txt", "w") as outfile:
    outfile.write("\n".join(retain_genomes))


#Crate dataframe with genome accession, number of total and unique 16S sequences
df = pd.DataFrame(list(set([_.description for _ in clean_records])), columns=['accession'])

seq_hash_per_genome = defaultdict(list)
for record in clean_records:
    seq_hash_per_genome[record.description].append(hashlib.md5(str(record.seq).encode('utf-8')).hexdigest()) #Assign hash to sequences

total_16S_per_genome = {k:len(v) for k, v in seq_hash_per_genome.items()}
unique_16S_per_genome = {k:len(set(v)) for k, v in seq_hash_per_genome.items()}


df['total_16S_copies'] = df['accession'].map(total_16S_per_genome)
df['unique_16S_copies'] = df['accession'].map(unique_16S_per_genome)

df.to_csv("../../supplementary_file_1/genomes_16S_info.csv", index=False)