#!/bin/bash
# Trim alignment using trimAl

trimal -in ../output/filtered_16S_seq_from_strep_genomes_aligned.fasta -out ../output/16S_extracted_from_genomes_trimmed_aln.fasta -automated1