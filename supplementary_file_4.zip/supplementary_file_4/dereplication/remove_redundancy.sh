#!/bin/bash
# remove_redundancy.sh
# The scipt was used to remove redundant sequences using vsearch 

vsearch --derep_fulllength ~/Desktop/Kiepas_et_al_2023_16S/supplementary_file_3/all_DNA_whole_16S_strep.fasta --output ~/Desktop/Kiepas_et_al_2023_16S/supplementary_file_4/dereplication/output/derep_DNA_whole_16S_strep.fasta --uc  ~/Desktop/Kiepas_et_al_2023_16S/supplementary_file_4/dereplication/output/dereplication_info.txt --sizeout