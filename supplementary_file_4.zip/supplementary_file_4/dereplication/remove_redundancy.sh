#!/bin/bash
# remove_redundancy.sh
# The scipt was used to remove redundant sequences using vsearch 

vsearch --derep_fulllength ../../supplementary_file_3/output/all_DNA_whole_16S_strep.fasta --output output_dereplication/derep_DNA_whole_16S_strep.fasta --uc  output/dereplication_info.txt --sizeout