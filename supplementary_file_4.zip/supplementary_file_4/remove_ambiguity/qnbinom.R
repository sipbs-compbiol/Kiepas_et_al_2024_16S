qnbinom(0.999, mu=5.5, size=0.021)
qnbinom(0.99, mu=5.5, size=0.021)
qnbinom(0.95, mu=5.5, size=0.021)