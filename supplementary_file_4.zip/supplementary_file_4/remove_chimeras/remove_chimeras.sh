#!/bin/bash
# remove_chimeric_seq.sh
# The scipt was used to remove chimeric sequences using vsearch

vsearch --uchime_denovo ~/Desktop/Kiepas_et_al_2023_16S/supplementary_file_4/remove_ambiguity/output/derep_DNA_whole_16S_strep_removed_ambiguity.fasta --chimeras ~/Desktop/Kiepas_et_al_2023_16S/supplementary_file_4/remove_chimeras/output/chimeras.fasta --nonchimeras ~/Desktop/Kiepas_et_al_2023_16S/supplementary_file_4/remove_chimeras/output/non_chimeras.fasta