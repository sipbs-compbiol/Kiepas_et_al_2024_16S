#!/bin/bash
# download_genomes
# Download genomes from NCBI


ncbi-genome-download bacteria -F all -l all --genera streptomyces -o ../data
