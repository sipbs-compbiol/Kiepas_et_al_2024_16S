library('ggplot2')
library(ggplot2)
library(dplyr)
library(tidyr)
library(ggpubr)
library(ggplot2)
library('ggExtra')

df <- read.csv("cluster_taxID_info.csv", header=TRUE)


pdf(file='../supplementary_file_7.pdf', width=12, height=8)
p<-ggplot(df, aes(x=number_of_cluster_members, group=theresholds_id, col=theresholds_id)) + stat_ecdf(geom = "step", pad=FALSE) +
  scale_color_manual(values=c("#F7F469", "#022857", "#223e92", "#1576bb", "#458ccc", "#6aa6da", "#96c0e6", "#9acfe6", "#9ddceb", "#DDF7FC", "#152238", "#087E16", "#168E25", "#2CAC3C", "#43C152", "#5CD16A", "#7DE089", "#AFFAB8", "#D9D608", "#E8E62B","#075711"), name='Clustering \nThereshold (%)') +
  scale_x_continuous(breaks = seq(0, 3600, 200), name ="Cluster Size") +
  coord_cartesian(ylim = c(.98, 1)) +
  stat_ecdf(geom = "step", pad = FALSE) + ylab("Proportion")  +
  theme()+ guides(color=guide_legend(ncol =1))
plot(p)
dev.off()

pdf(file='../supplementary_file_8.pdf', width=12, height=8)
p<-ggplot(df, aes(x=unique_number_of_cluster_members, group=theresholds_id, col=theresholds_id)) + stat_ecdf(geom = "step", pad=FALSE) +
  scale_color_manual(values=c("#F7F469", "#022857", "#223e92", "#1576bb", "#458ccc", "#6aa6da", "#96c0e6", "#9acfe6", "#9ddceb", "#DDF7FC", "#152238", "#087E16", "#168E25", "#2CAC3C", "#43C152", "#5CD16A", "#7DE089", "#AFFAB8", "#D9D608", "#E8E62B","#075711"), name='Clustering \nThereshold (%)') +
  xlim(0,100) + xlab("Unique taxID") +
  coord_cartesian(ylim = c(.98, 1)) +
  stat_ecdf(geom = "step", pad = FALSE) + ylab("Proportion")  +
  theme()+ guides(color=guide_legend(ncol =1))
plot(p)
dev.off()

data2 <- df[df$theresholds_id %in% c('100%', '98%', '99%'), ]
print(data2)

pdf(file='Figure_4.pdf', width=12, height=8)
p<-ggplot(data2, aes(x=unique_number_of_cluster_members, group=theresholds_id, col=theresholds_id)) + stat_ecdf(geom = "step", pad=FALSE) +
  scale_color_manual(values=c("#F7F469", '#022857', "#087E16"), name='Clustering \nThereshold (%)') +
  xlim(0,100) + xlab("Unique taxID") +
  coord_cartesian(ylim = c(.98, 1)) +
  stat_ecdf(geom = "step", pad = FALSE) + ylab("Proportion")  +
  theme()+ guides(color=guide_legend(ncol =1))
plot(p)
dev.off()


pdf(file='Figure_3.pdf', width=12, height=8)
p<-ggplot(data2, aes(x=number_of_cluster_members, group=theresholds_id, col=theresholds_id)) + stat_ecdf(geom = "step", pad=FALSE) +
  scale_color_manual(values=c("#F7F469", '#022857', "#087E16"), name='Clustering \nThereshold (%)') +
  scale_x_continuous(breaks = seq(0, 1600, 200), name ="Cluster Size") +
  coord_cartesian(ylim = c(.98, 1)) +
  stat_ecdf(geom = "step", pad = FALSE) + ylab("Proportion")  +
  theme()+ guides(color=guide_legend(ncol =1))
plot(p)
dev.off()



data <- read.csv("genomes_16S_info.csv")

data <- data[!data$total_16S_copies %in% c(0), ]

pdf(file='Figure_5.pdf', width=12, height=8)


p <- ggplot(data, aes(x=total_16S_copies, y=unique_16S_copies)) + 
  scale_x_continuous(breaks = seq(0, 12, 1), name ="16S rRNA copies per genome") +
  scale_y_continuous(name="Unique 16S rRNA copies per genome") + geom_count(colour='#4caf50', alpha=0.4)  + scale_size_area(max_size=13) + 
  theme(legend.position = "none") 
p + geom_text(data = ggplot_build(p)$data[[1]], 
              aes(x, y, label = n), color = "black")
dev.off()

data <- read.csv("genome_clusters_info.csv")
data <- data[!data$Total_genomes %in% c(1), ]

pdf(file='Figure_6.pdf', width=12, height=8)

p <- ggplot(data, aes(x=Total_genomes, y=Unique_names_per_cluter)) + 
  scale_x_continuous(breaks = seq(0, 35), name ="16S rRNA copies per genome") +
  scale_y_continuous(name="Unique 16S rRNA copies per genome") + geom_count(colour='#4caf50', alpha=0.4)  + scale_size_area(max_size=13) + 
  theme(legend.position = "none") 
p + geom_text(data = ggplot_build(p)$data[[1]], 
              aes(x, y, label = n), color = "black")
dev.off()



data <- read.csv("pyani_analysis_coverage_identity_representative.csv")

data2 <- data[!data$unique_taxa_names %in% c('6', '5','4', '3'), ]
data3 <- data[!data$unique_taxa_names %in% c('1', '2'), ]
pdf(file='Figure_7.pdf', width=30, height=15)


p1<-ggplot(data2, aes(x=cluster_id, y=coverage, col=comparision_type_species)) +geom_jitter(alpha=0.2)  + facet_wrap(unique_taxa_names ~., scales = 'free_x', nrow=7, shrink=TRUE, dir='h') + scale_y_continuous(name="Genome Coverage (%)") +
  scale_x_continuous(breaks = seq(0, 160, 10), name ="") + theme(legend.position="none")


p2<-ggplot(data3, aes(x=cluster_id, y=coverage, col=comparision_type_species)) +geom_jitter(alpha=0.2)  + facet_wrap(unique_taxa_names ~., scales = 'free_x', nrow=1, shrink=TRUE, dir='h') + scale_y_continuous(name="Genome Coverage (%)") +
  scale_x_continuous(breaks = seq(0, 20, 2), name ="Cluster ID") + theme(legend.position="none")




p4<-ggarrange(p1, p2,
              ncol = 1, nrow = 2, heights = c(2, 1, 1))
plot(p4)
dev.off()



pdf(file='Figure_8.pdf', width=30, height=15)


p1<-ggplot(data2, aes(x=cluster_id, y=identity, col=comparision_type_genus)) +geom_jitter(alpha=0.2)  + facet_wrap(unique_taxa_names ~., scales = 'free_x', nrow=7, shrink=TRUE, dir='h') + scale_y_continuous(name="Genome Identity (%)") +
  scale_x_continuous(breaks = seq(0, 160, 10), name ="") + theme(legend.position="none")


p2<-ggplot(data3, aes(x=cluster_id, y=identity, col=comparision_type_genus)) +geom_jitter(alpha=0.2)  + facet_wrap(unique_taxa_names ~., scales = 'free_x', nrow=1, shrink=TRUE, dir='h') + scale_y_continuous(name="Genome Identity (%)") +
  scale_x_continuous(breaks = seq(0, 20, 2), name ="Cluster ID") + theme(legend.position="none")




p4<-ggarrange(p1, p2,
              ncol = 1, nrow = 2, heights = c(2, 1, 1))
plot(p4)
dev.off()