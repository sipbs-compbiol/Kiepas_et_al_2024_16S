library("ape")
library(RColorBrewer)
library(dplyr)
library('ggplot2')
library('ggtree')
library(tidytree)
library(ggnewscale)
library("phytools")

gettreedata <- function(tree, meta){
  #get treedata object
  d<-meta[row.names(meta) %in% tree$tip.label,]
  d$label <- row.names(d)
  y <- full_join(as_tibble(tree), d, by='label')
  y <- as.treedata(y)
  return(y)
}

get_color_mapping <- function(data, col, cmap){
  labels <- (data[[col]])   
  names <- levels(as.factor(labels))
  n <- length(names)
  if (n<10){      
    colors <- suppressWarnings(c(brewer.pal(n, cmap)))[1:n]
  }
  else {
    colors <- colorRampPalette(brewer.pal(8, cmap))(n)
  }
  names(colors) = names
  return (colors)
}

ggplottree <- function(tree, meta, cols=NULL, cmaps=NULL, layout="rectangular",
                       offset=10, tiplabel=FALSE, tipsize=1) {
  
  y <- gettreedata(tree, meta)
  p <- ggtree(y, layout=layout, ladderize = TRUE, size=0.2) + geom_point2(aes(label=label,  subset = !is.na(as.numeric(label)) & as.numeric(label) == 1.1), colour='#008000', size=3)
  if (is.null(cols)){
    return (p)
  }
  
  col <- cols[1]
  cmap <- cmaps[1]
  df<-meta[tree$tip.label,][col]
  colors <- get_color_mapping(df, col, cmap)
  
  #tip formatting    
  p1 <- p + new_scale_fill() +geom_tippoint(mapping=aes(fill=.data[[col]]),size=tipsize,shape=22, stroke=NA) +
    scale_fill_manual(values=colors, na.value=NA)
  
  p2 <- p1
  if (length(cols)>1){
    for (i in 2:length(cols)){
      col <- cols[i]
      cmap <- cmaps[i]
      df <- meta[tree$tip.label,][col]
      type <- class(df[col,])            
      p2 <- p2 + new_scale_fill()
      p2 <- gheatmap(p2, df, offset=i*offset, width=.15,
                     colnames_angle=0, colnames_offset_y = .05)  
      #deal with continuous values
      if (type == 'numeric'){               
        p2 <- p2 + scale_color_brewer(type="div", palette=cmap)
      }
      else {
        colors <- get_color_mapping(df, col, cmap)
        p2 <- p2 + scale_fill_manual(values=colors, name=col) +theme(legend.position = "none")
      }          
    }
  }
  

  
  return(p2)
}






tree <- ape::read.tree('strep_annotated_tbe_fixed_visualization.new')
print(tree)
options(repr.plot.width=8, repr.plot.height=6)
df <- read.csv("strep_annotatations_16S_all_dispersions.csv", header=TRUE)

pdf(file = "16S_rRNA_all_dispersions.pdf",   # The directory you want to save the file in
    width = 30, # The width of the plot in inches
    height = 30) # The height of the plot in inches

row.names(df) <- df$Name

p <- ggplottree(tree, df, cols=c('species'),
                cmaps=c('Set1'), tipsize=50, offset=.05 ,layout='c') 



plot(p)
dev.off()

