# Supplementary file 10

This ZIP file contains all scripts I/O files for phylogenetic reconstruction in this manuscript. 