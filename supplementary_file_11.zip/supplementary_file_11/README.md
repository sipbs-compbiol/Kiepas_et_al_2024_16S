# README.md - supplementary file 10

This repository contains jupyter notebook used to collapse clades with a single species names, and the generated tree saved as a newick file. 

The current set of files and folder incude:
- `collapse_branches_AK.ipynb` - jupyter notebook used to collapse branches

- `collapsed_strep_tbe.new` - Newick file with a new gerenarted phylogenetic tree with collapsed branches. 