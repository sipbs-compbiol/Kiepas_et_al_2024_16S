# Supplementary file 2 - Filtration of 16S rRNA public databases. 

This file contains Python script used to filtrate 16S rRNA detabases to retain full length (1200bp or longer) *Streptomyces*, and standaralise base code to thymine, rather than uracil. 