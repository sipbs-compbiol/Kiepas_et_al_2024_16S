# get_complete_strep.py

This script was used to extract full length (>=1200bp) sequences
currently assigned to *Streptomyces* genomes from 4 databases that can be found
in supplementary file 1. 

NOTE for users accessing this script via GitHub: Due to the repository size limits for GitHub.com, 
sequences used in this manuscript must be obtained before running this script. For more information
please checked README.md file in supplementary file 1.